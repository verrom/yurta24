require 'spec_helper'

describe ContactForm do
  pending "add some examples to (or delete) #{__FILE__}"
end
