require 'spec_helper'

describe ContactFormController do

end
