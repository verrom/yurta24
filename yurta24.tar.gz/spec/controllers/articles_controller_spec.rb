require 'spec_helper'

describe ArticlesController do

end
