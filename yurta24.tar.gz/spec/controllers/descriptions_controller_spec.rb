require 'spec_helper'

describe DescriptionsController do

end
