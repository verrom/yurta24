require 'spec_helper'

describe ContactForm2Controller do

end
