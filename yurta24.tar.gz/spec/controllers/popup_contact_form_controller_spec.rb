require 'spec_helper'

describe PopupContactFormController do

end
