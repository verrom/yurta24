require 'spec_helper'

describe ItemsController do

end
