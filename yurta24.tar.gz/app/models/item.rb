class Item < ActiveRecord::Base
	dragonfly_accessor :image
end
