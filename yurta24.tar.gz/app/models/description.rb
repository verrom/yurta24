class Description < ActiveRecord::Base
end
