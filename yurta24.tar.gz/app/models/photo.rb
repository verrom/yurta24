class Photo < ActiveRecord::Base
end
