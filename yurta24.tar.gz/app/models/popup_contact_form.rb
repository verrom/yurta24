class PopupContactForm < ActiveRecord::Base
end
